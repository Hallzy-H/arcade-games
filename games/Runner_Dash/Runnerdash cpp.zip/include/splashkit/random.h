//
// SplashKit Generated Random C++ Code
// DO NOT MODIFY
//

#ifndef __random_h
#define __random_h

#include <string>
#include <vector>
using std::string;
using std::vector;

int rnd(int min, int max);
float rnd();
int rnd(int ubound);

#endif /* __random_h */
